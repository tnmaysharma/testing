package com.starterkit.domain;
import org.springframework.data.annotation.Id;

/**
 * @author 540010
 *
 */
public class Album {

	@Id
	private String id;

	private String title;
	private String artist;
	private String releaseYear;

	/**
	 * @param title
	 * @param artist
	 * @param releaseYear
	 */
	public Album(String title, String artist, String releaseYear) {
		this.title = title;
		this.artist = artist;
		this.releaseYear = releaseYear;
	}

//	/**
//	 * @param id
//	 * @param title
//	 * @param artist
//	 * @param releaseYear
//	 */
//
//	public Album(String id, String title, String artist, String releaseYear) {
//		this.title = title;
//		this.artist = artist;
//		this.releaseYear = releaseYear;
//		this.id = id;
//	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(String releaseYear) {
		this.releaseYear = releaseYear;
	}

	@Override
	public String toString() {
		return "Album [title=" + title + ", artist=" + artist + ", releaseYear=" + releaseYear + "]";
	}

}
